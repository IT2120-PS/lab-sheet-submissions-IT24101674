setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\SLIIT CAMPUS\\Year_2_Semester_1\\PS\\Labs\\Lab09")

#Q1
#consider 5% level of significance
#to run the one-sample t test, "t.test" command can be use as follow.
x<-c(3,7,11,0,7,0,4,5,6,2)
t.test(x, mu = 3)


#Q2 
#part 1
#n<=30, we can apply one sample t-test
#consider 5% level of significance
weight <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
t.test(weight, mu = 25, alternative= 'less')


#part 2
res <- t.test(weight, mu=25, alternative= "less")

# to extract p value for the test, use "res$statistic" command as follows.
res$statistic

# to extract p value for the test, use "res$p.value" command as follows.
res$p.value

# to extract confidence interval for the test, use "res$conf.int" command as follows.
res$conf.int

#Q3
#part 1
#gen random numbers from a normal distribution, we can use "rnorm" comm 
y <- rnorm(30, mean = 9.8, sd = 0.05)

#part 02
#when sample are lage enough t distribution cantbr approximated into normal distribution.
t.test(y, mu = 10, alternative = "greater")



#exercise 
#Q1
#part 1
# mu = 45, sd = 2
z<- rnorm(25, mean = 45, sd = 2)


#part 2
t.test(z, mu = 46, alternative = "less")
